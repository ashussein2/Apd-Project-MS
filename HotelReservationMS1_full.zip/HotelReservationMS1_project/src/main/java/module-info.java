module com.hotel.app {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.hibernate.orm.core;
    requires java.sql;
    requires com.google.guice;
    requires org.mindrot.jbcrypt;

    opens com.hotel.controller to javafx.fxml, com.google.guice;
    opens com.hotel.app to javafx.fxml;
    opens com.hotel.model to org.hibernate.orm.core;

    exports com.hotel.app;
}
