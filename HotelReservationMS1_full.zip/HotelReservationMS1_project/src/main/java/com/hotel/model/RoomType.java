package com.hotel.model;

public enum RoomType {
    SINGLE,
    DOUBLE,
    DELUXE,
    PENTHOUSE
}
