package com.hotel.controller;

import com.hotel.app.AppConfig;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class LauncherController {

    @FXML
    private BorderPane root;

    private Stage getStage() {
        return (Stage) root.getScene().getWindow();
    }

    @FXML
    private void openKiosk(ActionEvent event) {
        loadScene("/com/hotel/view/kiosk_view.fxml", "Kiosk - Self Service");
    }

    @FXML
    private void openAdmin(ActionEvent event) {
        loadScene("/com/hotel/view/admin_login_view.fxml", "Admin - Login");
    }

    @FXML
    private void openFeedback(ActionEvent event) {
        loadScene("/com/hotel/view/feedback_view.fxml", "Guest Feedback");
    }

    private void loadScene(String fxml, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml));
            loader.setControllerFactory(AppConfig.getInjector()::getInstance);
            Stage stage = getStage();
            stage.setTitle(title);
            stage.setScene(new Scene(loader.load()));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
