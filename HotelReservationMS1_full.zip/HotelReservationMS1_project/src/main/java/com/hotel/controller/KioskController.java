package com.hotel.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.time.LocalDate;

public class KioskController {

    @FXML
    private TextField adultsField;

    @FXML
    private TextField childrenField;

    @FXML
    private DatePicker checkInDate;

    @FXML
    private DatePicker checkOutDate;

    @FXML
    private TextField nameField;

    @FXML
    private TextField phoneField;

    @FXML
    private TextField emailField;

    @FXML
    private CheckBox wifiCheck;

    @FXML
    private CheckBox breakfastCheck;

    @FXML
    private CheckBox parkingCheck;

    @FXML
    private CheckBox spaCheck;

    @FXML
    private Label estimateLabel;

    @FXML
    private void onBack(ActionEvent e) {
        Stage stage = (Stage) estimateLabel.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void onShowPolicy(ActionEvent e) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Booking Policy");
        alert.setHeaderText("Room Booking Policy");
        alert.setContentText("Sample policy text for milestone 1. You can update this later.");
        alert.showAndWait();
    }

    @FXML
    private void onConfirm(ActionEvent e) {
        if (!validateFields()) {
            return;
        }
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Reservation created");
        alert.setHeaderText("Reservation captured (UI only)");
        alert.setContentText("For milestone 1 this only demonstrates the front-end flow.");
        alert.showAndWait();
    }

    private boolean validateFields() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        LocalDate in = checkInDate.getValue();
        LocalDate out = checkOutDate.getValue();

        if (name.isEmpty() || phone.isEmpty() || in == null || out == null) {
            showError("Please fill all required fields (name, phone, dates).");
            return false;
        }
        if (!out.isAfter(in)) {
            showError("Check-out date must be after check-in date.");
            return false;
        }
        return true;
    }

    private void showError(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Validation error");
        alert.setHeaderText("Please fix the highlighted issues");
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
