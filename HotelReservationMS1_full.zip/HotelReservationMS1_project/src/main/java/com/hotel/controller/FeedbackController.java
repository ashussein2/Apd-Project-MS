package com.hotel.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class FeedbackController {

    @FXML
    private ComboBox<Integer> ratingCombo;

    @FXML
    private TextArea commentsArea;

    @FXML
    private Label statusLabel;

    @FXML
    public void initialize() {
        ratingCombo.getItems().addAll(1, 2, 3, 4, 5);
    }

    @FXML
    private void onSubmit(ActionEvent e) {
        Integer rating = ratingCombo.getValue();
        if (rating == null) {
            statusLabel.setText("Please pick a rating.");
            return;
        }
        statusLabel.setText("Thank you for your feedback!");
        commentsArea.clear();
        ratingCombo.setValue(null);
    }

    @FXML
    private void onClose(ActionEvent e) {
        Stage stage = (Stage) statusLabel.getScene().getWindow();
        stage.close();
    }
}
