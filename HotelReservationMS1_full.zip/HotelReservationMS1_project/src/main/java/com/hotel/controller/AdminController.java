package com.hotel.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class AdminController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label messageLabel;

    @FXML
    private void onLogin(ActionEvent e) {
        String user = usernameField.getText().trim();
        String pass = passwordField.getText().trim();

        if (user.isEmpty() || pass.isEmpty()) {
            messageLabel.setText("Please enter both username and password.");
            return;
        }

        // Milestone 1: simple dummy check
        if (user.equals("admin") && pass.equals("admin")) {
            messageLabel.setText("Login successful (demo). Dashboard to be implemented.");
        } else {
            messageLabel.setText("Invalid credentials (demo check).");
        }
    }

    @FXML
    private void onCancel(ActionEvent e) {
        Stage stage = (Stage) messageLabel.getScene().getWindow();
        stage.close();
    }
}
